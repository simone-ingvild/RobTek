#include "EAN.h"
#include <iostream>
using namespace std;

EAN::EAN()
{
}

EAN::EAN(string etEANnr)
{
	EANnr = etEANnr;
}

bool EAN::isValid()
{
	if (EANnr.size() != 13)
		return false;

	int sumUligeTal = 0;
	int sumLigeTal = 0;

	for (int i = 1; i < 13; i = i + 2)
	{
		sumUligeTal += stoi(EANnr.substr(i, 1));
	}
	for (int i = 0; i < 13; i = i + 2)
	{
		sumLigeTal += stoi(EANnr.substr(i, 1));
	}

	if ((sumUligeTal * 3 + sumLigeTal) % 10 == 0)
		return true;
	return false;
}

string EAN::getEANnr()
{
	return EANnr;
}

/*Precondition: the parameter is a valid ISBN - code
string EAN::convertISBNtoEAN(string ISBN)
{
	string s("978");
	s += ISBN.substr(5, 1);
	s += ISBN.substr(7, 2);
	s += ISBN.substr(10,6);

	int sumUligeTal = 0;
	int sumLigeTal = 0;
	int sum = 0;
	for (int i = 1; i < 12; i = i + 2)
	{
		sumUligeTal += stoi(s.substr(i, 1));
	}
	for (int i = 0; i < 12; i = i + 2)
	{
		sumLigeTal += stoi(s.substr(i, 1));
	}

	sum = sumUligeTal * 3 + sumLigeTal;
	
	s += to_string(10 - sum % 10);
	
	return s;
}*/


EAN::~EAN()
{
}


#include "EAN.h";
#include "ISBN.h"
#include <iostream>
using namespace std;
int main()
{
	EAN e("9780674062313");
	cout << e.isValid() << endl;

	EAN f("5714946000431");
	cout << f.isValid() << endl;
	
	ISBN isbn("ISBN 0-13-222220-5");

	EAN g = isbn.convertISBNtoEAN();
	
	cout << g.getEANnr() << endl;
	cout << g.isValid() << endl;

}
#pragma once
#include <string>
using namespace std;
class EAN
{
public:
	EAN();
	EAN(string etEANnr);
	bool isValid();
	string getEANnr();
	~EAN();

private:
	string EANnr;
};


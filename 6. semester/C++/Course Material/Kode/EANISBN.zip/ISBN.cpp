#include "ISBN.h"
#include <iostream>
using namespace std;

ISBN::ISBN()
{
}

ISBN::ISBN(string etISBNnr)
{
	ISBNnr = etISBNnr;
}

// Precondition: the parameter is a valid ISBN-code
EAN ISBN::convertISBNtoEAN()
{
	string s("978");
	s += ISBNnr.substr(5, 1);
	s += ISBNnr.substr(7, 2);
	s += ISBNnr.substr(10, 6);

	int sumUligeTal = 0;
	int sumLigeTal = 0;
	int sum = 0;
	for (int i = 1; i < 12; i = i + 2)
	{
		sumUligeTal += stoi(s.substr(i, 1));
	}
	for (int i = 0; i < 12; i = i + 2)
	{
		sumLigeTal += stoi(s.substr(i, 1));
	}

	sum = sumUligeTal * 3 + sumLigeTal;

	s += to_string(10 - sum % 10);

	return EAN(s);
}

ISBN::~ISBN()
{}

#pragma once
#include <string>
#include "EAN.h"
using namespace std;
class ISBN
{

public:
	ISBN();
	ISBN(string etEANnr);
	EAN convertISBNtoEAN();
	~ISBN();

private:
	string ISBNnr;
}

;
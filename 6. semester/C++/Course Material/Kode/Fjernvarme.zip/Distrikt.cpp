#include "Distrikt.h"

Distrikt::Distrikt()
{
}

Distrikt::Distrikt(int pris)
{
	prisM3 = pris;
	antalForbrugere = 0;
}

void Distrikt::addForbruger(Forbruger &f)
{
	forbrugere.push_back(&f);
	antalForbrugere++;
}

int Distrikt::afregnForbruger(int maaler)
{
	for (int i = 0; i < antalForbrugere; i++)
	{
		Forbruger* f = forbrugere[i];
		if (f->getMaalerNr() == maaler)
			return f->beregnForbrug() * prisM3;
	}
	return -1;
}

Distrikt::~Distrikt()
{
}

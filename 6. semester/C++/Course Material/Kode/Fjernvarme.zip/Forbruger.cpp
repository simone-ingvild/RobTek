#include "Forbruger.h"
#include <string>
#include <iostream>


Forbruger::Forbruger()
{
}

Forbruger::Forbruger(string n, int maaler, int max):
	navn(n), maalerNr(maaler), nyAflaesning(0), glAflaesning(0), maalerMax(max)
{}

string Forbruger::getNavn()
{
	return navn;
}

void Forbruger::setNavn(string n)
{
	navn = n;
}

void Forbruger::aflaesMaaler(int stand)
{
	glAflaesning = nyAflaesning;
	nyAflaesning = stand;
}

int Forbruger::beregnForbrug()
{
	int tempNy = nyAflaesning;
	if (nyAflaesning < glAflaesning)
		tempNy += maalerMax + 1;
	return tempNy - glAflaesning;
}

int Forbruger::getMaalerNr()
{
	return maalerNr;
}

Forbruger::~Forbruger()
{
}

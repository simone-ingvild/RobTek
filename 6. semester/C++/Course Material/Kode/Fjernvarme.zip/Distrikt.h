#pragma once
#include <vector>;
#include "Forbruger.h"
using namespace std;
class Distrikt
{
public:
	Distrikt();
	Distrikt(int);
	void addForbruger(Forbruger &f);
	int afregnForbruger(int);
	~Distrikt();
private:
	vector<Forbruger*> forbrugere;
	int antalForbrugere;
	int prisM3;
};


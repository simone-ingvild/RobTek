#pragma once
#include <string>
using namespace std;

class Forbruger
{
public:
	Forbruger();
	Forbruger(string, int, int);
	string getNavn();
	void setNavn(string);
	int getMaalerNr();
	void aflaesMaaler(int);
	int beregnForbrug();
	~Forbruger();
private:
	string navn;
	int maalerNr;
	int nyAflaesning;
	int glAflaesning;
	int maalerMax;
};


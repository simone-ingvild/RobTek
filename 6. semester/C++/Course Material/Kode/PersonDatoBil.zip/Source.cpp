#include <iostream>

#include "Dato.h"
#include "Person.h"


using namespace std;

int main()
{
	
	Person peter("Peter Hansen", "phdk@gmail.com", Dato(19521017));

	Bil bil("MH40136", 1966);

	peter.addBil(bil);

	cout << peter.getBil().getAargang() << endl;

}

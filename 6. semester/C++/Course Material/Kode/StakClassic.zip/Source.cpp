#include <iostream>

#include "Dato.h"
#include "Person.h"

#include "Stak.h"

using namespace std;

int main()
{

	Person peter("Peter Hansen", "phdk@gmail.com", Dato(19521017));
	Person ole("Ole Dolriis", "olsendk@gmail.com", Dato(19530714));
	Person maia("Maia Roberts", "maia@gmail.com", Dato(20220902));

	

	

	Stak stak("Min Stak");
	stak.push(peter);
	stak.push(ole);
	stak.push(maia);

	for (int i = 0; i < stak.getStakSize(); i++)
	{
		Person person = stak.getElement(i);
		cout << "Person i indeks " << i << ":" << person.getNavn() << endl;
	}
	Person person = stak.pop();
	cout << person.getNavn() << " er blevet fjernet fra stakken." << endl;
	person = stak.pop();
	cout << person.getNavn() << " er blevet fjernet fra stakken." << endl;
	person = stak.pop();
	cout << person.getNavn() << " er blevet fjernet fra stakken." << endl;

	for (int i = 0; i < stak.getStakSize(); i++)
	{
		Person person = stak.getElement(i);
		cout << "Person i indeks " << i << ":" << person.getNavn() << endl;
	}

	person = stak.pop();
}


	


#include "Person.h"
Person::Person(){}

Person::Person(string n, string m,Dato f)
{
	navn = n;
	mail = m;
	foedselsdag = f;
}

void Person::addBil(Bil b)
{
	bil = b;
}

string Person::getNavn()
{
	return navn;
}

string Person::getMail()
{
	return mail;
}

Dato Person::getFoedselsdag()
{
	return foedselsdag;
}

Bil Person::getBil()
{
	return bil;
}

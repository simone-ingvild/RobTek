#pragma once
#ifndef STAK_H
#define STAK_H
#include<vector>
#include "Person.h"
class Stak
{
public:
	Stak();
	Stak(string);
	bool isEmpty();
	string getNavn();
	int getStakSize();
	void push(Person p);
	Person pop();
	Person getElement(int);
	~Stak();
private:
	string navn;
	vector<Person> personStak;
	vector<Person>::iterator iter;
	int stakSize;

};

#endif


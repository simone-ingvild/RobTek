#include <string>
#include "Dato.h"
#include "Bil.h"
#pragma once
class Person
{
public:
	Person();
	Person(string, string, Dato);
	string getNavn();
	string getMail();
	Dato getFoedselsdag();
	Bil getBil();
	void addBil(Bil);
private:
	string navn;
	string mail;
	Dato foedselsdag;
	Bil bil;
};


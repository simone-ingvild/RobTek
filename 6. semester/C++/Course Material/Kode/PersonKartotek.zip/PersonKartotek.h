#pragma once
#include <vector>
#include <string>
#include "Person.h"
using namespace std;

class PersonKartotek
{
public:
	PersonKartotek();
	PersonKartotek(string);

	string getNavn();
	int getAntalPersoner();
	Person& getElement(int);

	void addPerson(Person& p);

	~PersonKartotek();
private:
	string navn;
	vector<Person>* personer;
	int antalPersoner;

};


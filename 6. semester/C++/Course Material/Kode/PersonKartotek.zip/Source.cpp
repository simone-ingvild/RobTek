#include <iostream>

#include "Dato.h"
#include "Person.h"
#include "PersonKartotek.h"
#include "Stak.h"

using namespace std;

int main()
{

	Person peter("Peter Hansen", "phdk@gmail.com", Dato(19521017));
	Person ole("Ole Dolriis", "olsendk@gmail.com", Dato(19530714));
	Person maia("Maia Roberts", "maia@gmail.com", Dato(20220902));

	PersonKartotek pK("Mit kartotek");

	pK.addPerson(peter);
	pK.addPerson(ole);
	pK.addPerson(maia);

	for (int i = 0; i < pK.getAntalPersoner(); i++)
	{
		Person person = pK.getElement(i);
		cout << "Person i indeks " << i << ":" << person.getNavn() << endl;
	}
	
}


	


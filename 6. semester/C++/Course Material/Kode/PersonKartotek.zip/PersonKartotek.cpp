#include "PersonKartotek.h"

PersonKartotek::PersonKartotek()
{
	antalPersoner = 0;
	navn = "";
}

PersonKartotek::PersonKartotek(string n)
{
	personer = new vector<Person>();
	antalPersoner = 0;
	navn = n;
}

string PersonKartotek::getNavn()
{
	return navn;
}

int PersonKartotek::getAntalPersoner()
{
	return antalPersoner;
}

void PersonKartotek::addPerson(Person& p)
{
	personer->push_back(p);
	antalPersoner++;
}

Person& PersonKartotek::getElement(int i)
{
	return personer->at(i);
}

PersonKartotek::~PersonKartotek()
{
	delete personer;
}
#include "Bil.h"
Bil::Bil(){}

Bil::Bil(string r, int a)
{
	regNr = r;
	aargang = a;
}

string Bil::getRegNr()
{
	return regNr;
}

int Bil::getAargang()
{
	return aargang;
}

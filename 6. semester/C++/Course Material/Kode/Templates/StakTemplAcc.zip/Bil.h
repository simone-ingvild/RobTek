#pragma once
#include <string>
using namespace std;
class Bil
{
public:
	Bil();
	Bil(string, int);
	string getRegNr();
	int getAargang();
private:
	string regNr;
	int aargang;
};


#include <iostream>
#include "Stak.h"
#include "Bil.h"
#include "Dato.h"

using namespace std;

int main()
{

	Bil knuds("MA39604", 1938);
	Bil oles("MH40136", 1966);
	Bil ivers("KD23419", 1961);
	
	Stak<Bil> stak("Min bilstak");

	stak.push(knuds),
	stak.push(oles);
	stak.push(ivers);

	Bil bil = stak.pop();
	cout << bil.getRegNr() << " er blevet fjernet fra stakken." << endl;
	bil = stak.pop();
	cout << bil.getRegNr() << " er blevet fjernet fra stakken." << endl;
	bil = stak.pop();
	cout << bil.getRegNr() << " er blevet fjernet fra stakken." << endl;

	if (stak.isEmpty())
		cout << "bilstakken er tom" << endl;

	Dato knud(19190609);
	Dato ole(19530714);
	Dato iver(19010206);

	Stak<Dato> stakD("Min datostak");

	stakD.push(knud),
	stakD.push(ole);
	stakD.push(iver);

	Dato dato = stakD.pop();
	cout << dato.getDatoen() << " er blevet fjernet fra stakken." << endl;
	dato = stakD.pop();
	cout << dato.getDatoen() << " er blevet fjernet fra stakken." << endl;
	dato = stakD.pop();
	cout << dato.getDatoen() << " er blevet fjernet fra stakken." << endl;

	if (stakD.isEmpty())
		cout << "datostakken er tom" << endl;
	
}


	


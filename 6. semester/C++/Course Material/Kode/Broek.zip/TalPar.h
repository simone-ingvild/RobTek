#pragma once
class TalPar
{
public:
	TalPar(void);
	TalPar(int etX, int etY);
	int getX();
	int getY();
	~TalPar(void);
private:
	int	x;
	int	y;
};




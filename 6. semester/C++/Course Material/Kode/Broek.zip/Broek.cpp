#include "Broek.h"
#include <iostream>

using namespace std;

Broek::Broek(void)
{
}
Broek::Broek(int aN, int aD)
{
	TalPar p(aN, aD);
	p = forkort(p);
	taeller = p.getX();
	naevner = p.getY();
}

int Broek::getNaevner()
{
	return naevner;
}

int Broek::getTaeller()
{
	return taeller;
}

Broek Broek::adder(Broek aF)
{
	int commonD = aF.getNaevner() * getNaevner();
	int TaellerS = aF.getTaeller() * getNaevner() +
		getTaeller() * aF.getNaevner();
	return Broek(TaellerS, commonD);
}

Broek Broek::subtraher(Broek aF)
{
	int commonD = aF.getNaevner() * getNaevner();
	int TaellerS = getTaeller() * aF.getNaevner() -
		aF.getTaeller() * getNaevner();
	return Broek(TaellerS, commonD);
}

Broek Broek::multiplicer(Broek enB)
{
	return Broek(getTaeller() * enB.getTaeller(), getNaevner() * enB.getNaevner());
}

Broek Broek::divider(Broek enB)
{
	return Broek(getTaeller() * enB.getNaevner(), getNaevner() * enB.getTaeller());
}

TalPar Broek::forkort(TalPar aP)
{
	int greatestCD = stoersteFaellesDivisor(aP);
	return(TalPar(aP.getX() / greatestCD, aP.getY() / greatestCD));
}
int Broek::stoersteFaellesDivisor(TalPar aP)
{	//Rekursiv metode inspireret af Euklids gcd
	int result = 1;
	if (aP.getX() % aP.getY() == 0)
		result = aP.getY();
	else
		result = stoersteFaellesDivisor(TalPar(aP.getY(), aP.getX() % aP.getY()));
	return result;
}

Broek Broek::operator+(Broek b)
{
	return adder(b);
}

Broek Broek::operator-(Broek b)
{
	return subtraher(b);
}

Broek Broek::operator*(Broek b)
{
	return multiplicer(b);
}

Broek Broek::operator/(Broek b)
{
	return divider(b);
}
Broek::~Broek(void)
{
}


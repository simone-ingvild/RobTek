#include "TalPar.h"


TalPar::TalPar(void)
{
}
TalPar::TalPar(int anX, int aY)
{
	x = anX;
	y = aY;
}

int TalPar::getX()
{
	return x;
}

int TalPar::getY()
{
	return y;
}

TalPar::~TalPar(void)
{
}

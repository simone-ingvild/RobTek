#pragma once
#include "TalPar.h"
class Broek
{
public:
	Broek(void);
	Broek(int aN, int aD);

	int getTaeller();
	int getNaevner();
	Broek adder(Broek);
	Broek subtraher(Broek);
	Broek multiplicer(Broek);
	Broek divider(Broek);
	Broek operator+(Broek);
	Broek operator-(Broek);
	Broek operator*(Broek);
	Broek operator/(Broek);

	~Broek(void);

private:
	TalPar forkort(TalPar aP);
	int stoersteFaellesDivisor(TalPar aP);

	int taeller;
	int naevner;
};



#include <iostream>
#include "Broek.h"
#include "TalPar.h"
using namespace std;

int main()
{
	Broek a(1, 2);
	Broek b(1, 4);
	Broek c = a + b;

	cout << c.getTaeller() << "/" << c.getNaevner() << endl;;

	Broek d(1, 2);
	Broek e(1, 4);
	Broek f = d / e;

	cout << f.getTaeller() << "/" << f.getNaevner() << endl;
	return 0;
}

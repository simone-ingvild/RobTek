#include "EMA.h"
EMA::EMA(){}

EMA::EMA(string email)
{
	emailAddress = email;
}

string EMA::getEMA() const
{
	return emailAddress;
}

int EMA::snabelA() const
{
	int antalS = 0; int pos = 0;
	for (int i = 0; i < emailAddress.length(); i++)
	{
		if (emailAddress.at(i) == '@')
		{
			if (antalS > 0)
				return -1;
			if (i <= 4 || i > 64)
				return -1;
			antalS++;
			pos = i;
		}
	}
	if (pos > 0)
		return pos;
	return -1;
}

bool EMA::dot() const
{
	int posA = snabelA();
	int antalD = 0;
	for (int i = 0; i < emailAddress.length(); i++)
	{
		if (emailAddress.at(i) == '.')
		{
			if (i < posA + 3)
				return false;
			if (antalD == 1)
				return false;
			antalD++;
		}
	}
	if (antalD == 0)
		return false;
	return true;
}

bool EMA::checkLengths() const
{
	int length = emailAddress.length();
	if (length - snabelA() < 5 || length - snabelA() > 255)
		return false;
	return true;
}

bool EMA::checkChars() const
{
	for (int i = 0; i < emailAddress.length(); i++)
	{
		char c = emailAddress.at(i);
		if (!(c == '@' || c == '.' || c == '%' || c == '&' ||(c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')))
			return false;
	}
	return true;
}

bool EMA::isValid() const
{
	if (snabelA() == -1)
		return false;
	if (!dot())
		return false;
	if (!checkLengths())
		return false;
	if (!checkChars())
		return false;
	return true;
}

EMA::~EMA(){}
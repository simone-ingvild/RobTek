#pragma once
#include <string>
using namespace std;
class EMA
{
public:
	EMA();
	EMA(string);
	~EMA();
	string getEMA() const;    
	bool isValid() const;		// den centrale metode     
private:
	int snabelA() const;		// returner @ position; -1 hvis @ st�r forkert, mangler
								// eller mere end et @
	bool dot() const;   		// true hvis . er mindst to positioner efter @, og kun et .
								// ellers false
	bool checkLengths() const;	// precondition: snabelA() returnerer ikke -1; local max 64
								// domain max. 255
	bool checkChars() const;	// lovlige karakterer a-z, A-Z, 0-9 og @ % & .  

	string emailAddress;
};


